public class SnakeGame {
    //SHALINI CHATTERJEE
    public static void main(String args[]){


        new GameFrame();

    }
    
}
